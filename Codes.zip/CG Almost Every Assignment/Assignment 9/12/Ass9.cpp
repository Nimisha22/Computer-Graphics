#include<iostream>
#include<dos.h>
#include<stdio.h>
#include<math.h>
#include<conio.h>
#include<graphics.h>
using namespace std;

void draw_cube(double edge[20][3])
{
        int gd=DETECT,gm;
        double  x1, y1, x2, y2;
        initgraph(&gd,&gm,"C:\\TURBOC3\\BGI");
	int i;
	clearviewport();

	for(i=0;i<19;i++)
    {
	       	x1= edge[i][0]+edge[i][2]*(cos(2.3562));
	       	y1= edge[i][1]-edge[i][2]*(sin(2.3562));
	       	x2= edge[i+1][0]+edge[i+1][2]*(cos(2.3562));
	       	y2= edge[i+1][1]-edge[i+1][2]*(sin(2.3562));
	       	// bar3d(320,220 ,400, 280, 50, 1);
            line(x1+320,240-y1,x2+320,240-y2);
    }

	line(320,240,320,25);
	line(320,240,550,240);
	line(320,240,150,410);
	getch();
    closegraph();
}

void r_rotate(double edge[20][3])
{
      	int ch;
      	int i;
      	double temp,theta,temp1;
    	//clrscr();
        cout<<"\n-=[ Rotation About ]=-";

        cout<<"\n1:==> X-Axis ";

        cout<<"\n2:==> Y-Axis ";

        cout<<"\n3:==> Z-Axis ";

       	cout<<" \nEnter Your Choice: ";
        cin>>ch;

        switch(ch)
        {
	     	case 1:
                cout<<" \nEnter The Angle: ";
                cin>>theta;
                theta=(theta*3.14)/180;
                for(i=0;i<20;i++)
			  	{
			    	edge[i][0]=edge[i][0];
			      	temp=edge[i][1];
			      	temp1=edge[i][2];
			    	edge[i][1]=temp*cos(theta)-temp1*sin(theta);
			    	edge[i][2]=temp*sin(theta)+temp1*cos(theta);
			  	}
                draw_cube(edge);
                break;



	     	case 2:
                cout<<" \nEnter The Angle: ";

                cin>>theta;
                theta=(theta*3.14)/180;
                for(i=0;i<20;i++)
			  	{
			    	edge[i][1]=edge[i][1];
			      	temp=edge[i][0];
			      	temp1=edge[i][2];
			    	edge[i][0]=temp*cos(theta)+temp1*sin(theta);
			    	edge[i][2]=-temp*sin(theta)+temp1*cos(theta);
			  	}
                draw_cube(edge);
                break;

	     	case 3:

                cout<<" \nEnter The Angle: ";

                cin>>theta;
                theta=(theta*3.14)/180;
                for(i=0;i<20;i++)
			  	{
			    	edge[i][2]=edge[i][2];
			      	temp=edge[i][0];
			      	temp1=edge[i][1];
			    	edge[i][0]=temp*cos(theta)-temp1*sin(theta);
			    	edge[i][1]=temp*sin(theta)+temp1*cos(theta);
			  	}
                draw_cube(edge);
                break;
    }//rotation switch ends here
}//rotate ends here

void reflect(double edge[20][3])
{
    	int ch;
    	int i;
    	//clrscr();
        cout<<"-=[ Reflection About ]=-";

 	cout<<"\n1:==> X-Axis";

    cout<<"\n2:==> Y-Axis";

    cout<<"\n3:==> Z-Axis";

    cout<<"\nEnter Your Choice:= ";
    cin>>ch;


 	switch(ch)
    {
	     	case 1:
                for(i=0;i<20;i++)
			  	{
			    	edge[i][0]=edge[i][0];
			    	edge[i][1]=-edge[i][1];
			    	edge[i][2]=-edge[i][2];
			  	}
                draw_cube(edge);
                break;


	     	case 2:
	     		for(i=0;i<20;i++)
			  	{
			    	edge[i][1]=edge[i][1];
			    	edge[i][0]=-edge[i][0];
			    	edge[i][2]=-edge[i][2];
			  	}
                draw_cube(edge);
                break;

	     	case 3:
	     		for(i=0;i<20;i++)
			  	{
			    	edge[i][2]=edge[i][2];
			    	edge[i][0]=-edge[i][0];
			    	edge[i][1]=-edge[i][1];
			  	}
                draw_cube(edge);
                break;
    }


}//reflect ends here

int main()
{
        int choice;
      	double edge[20][3]=
		     	{
			100,0,0,
			100,100,0,
			0,100,0,
			0,100,100,
			0,0,100,
			0,0,0,
			100,0,0,
			100,0,100,
			100,75,100,
			100,100,100,
			100,100,100,
			100,100,0,
			100,100,100,
			100,75,100,
			100,100,100,
			0,100,100,
			0,100,0,
			0,0,0,
			0,0,100,
			100,0,100
		     	};

        while(1)
        {

        	cout<<"\n*****ASSSIGNMENT 9*****";

            cout<<"\n\n1:==> Draw Cube";

            cout<<"\n2:==>Rotation ";

            cout<<"\n3:==>Reflection";

            cout<<"\n4:==>Exit";

            cout<<"\nEnter Your Choice :=";
            cin>>choice;

            switch(choice)
            {
			 case 1:
				draw_cube(edge);
				break;

			 case 2:
				r_rotate(edge);
				break;

			 case 3:
				reflect(edge);
				break;

			 case 4:
				exit(0);

	                 default:
        	        	cout<<"\nSelect a valid option...!!! ";


			 }


        }



         getch();
             //break;
	         closegraph();
	         return 0;
}
