#include <conio.h>
#include <graphics.h>
#include <math.h>
#include <stdio.h>
#include <string.h>
#include <iostream>
#define nullptr 0
using namespace std;
class matrix {
 public:
 double** val;
 int rows, cols;

 matrix(int row, int col) {
 val = new double*[row];
 for (int i = 0; i < row; i++)
    {
       val[i] = new double[col];
 for (int j = 0; j < col; j++)
       val[i][j] = 0;
    }
 rows = row;
 cols = col;
 }
 // Operator overloading
matrix* operator*(matrix* other) {
 if (other == nullptr || cols != other->rows)
 return nullptr;
 int i, j, k;
 matrix* result = new matrix(rows, other->cols);
 for (i = 0; i < rows; i++) {
 for (j = 0; j < other->cols; j++) {
 result->val[i][j] = 0;
 for (k = 0; k < other->rows; k++) {
 result->val[i][j] += val[i][k] * other->val[k][j];
 }
 }
 }
 return result;
 }
};
// this function returns a column matrix
matrix* col_mat(int first, int second, int third) {
 matrix* result = new matrix(4, 1);
 result->val[0][0] = first;
 result->val[1][0] = second;
 result->val[2][0] = third;
 result->val[3][0] = 1;
 return result;
}
 // For adding main values of diagonal (1,-1,1)
matrix* diag4(double sx, double sy, double sz) {
 matrix* result = new matrix(4, 4);
 result->val[0][0] = sx;
 result->val[1][1] = sy;
 result->val[2][2] = sz;
 result->val[3][3] = 1;
 return result;
}
matrix* reflect(matrix* original,int a, int b, int c) {
 matrix* change = nullptr;
 change = diag4(a,b,c);
 // Multiplying our two Matrix here operator op overloading will be done
 matrix* result = *change * original;
 return result;
}
int main() {

 double x, y, z;
 int choice;

 int gdriver = DETECT, gmode,n_poly;
 initgraph( & gdriver, & gmode, "C: \TC\ BGI");
 cout << "Results Won't Be Printed Because Z axis is imaginary...\n ";
 cout << "Enter X coordinate : ";
 cin >> x;
 cout << "Enter Y coordinate : ";
 cin >> y;
 cout << "Enter Z coordinate : ";
 cin >> z;
 matrix* mat = col_mat(x, y, z);
 cout << "\n\n Select \n";
 cout << "Press 1 for Reflection about z-axis\n";
 cout << "Press 2 for Reflection about XZ Plane\n";
 cout << "Press 3 to Exit\n";
 char axis;
 double degree;
 restart:
 cout << "Enter your choice: ";
 cin >> choice;
 switch (choice) {
 case 1:
 mat = reflect(mat,-1,-1,1);
 cout << "\n After reflection the points are: ";
 break;
 case 2:
 cout << " \n ";
 mat = reflect(mat,1,-1,1);
 cout << "\n After reflection the points are: ";
 break;
 case 3:
 goto end;
 default:
 cout << "Please enter a valid choice!";
 goto restart;
 }
 // Displaying our coordinates from matrix
 x = mat->val[0][0];
 y = mat->val[1][0];
 z = mat->val[2][0];
 cout << '\n' << '(' << x << ", " << y << ", " << z << ')';
end:
 getch();
 return 0;
}
