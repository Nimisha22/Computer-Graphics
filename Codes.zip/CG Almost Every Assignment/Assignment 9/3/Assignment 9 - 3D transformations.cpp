#include <math.h>
#include <stdio.h>
#include <iostream>
#define nullptr 0
using namespace std;
class matrix {
 public:
 double** val;
 int rows, cols;
 matrix(int row, int col) {
 val = new double*[row];
 for (int i = 0; i < row; i++) {
 val[i] = new double[col];
 for (int j = 0; j < col; j++)
 val[i][j] = 0;
 }
 rows = row;
 cols = col;
 }
 void flush() {
 for (int i = 0; i < rows; i++)
 delete[] val[i];
 delete val;
 }
 matrix* operator*(matrix* other) {
 if (other == nullptr || cols != other->rows)
 return nullptr;
 int i, j, k;
 matrix* result = new matrix(rows, other->cols);
 for (i = 0; i < rows; i++) {
 for (j = 0; j < other->cols; j++) {
 result->val[i][j] = 0;
 for (k = 0; k < other->rows; k++) {
 result->val[i][j] += val[i][k] * other->val[k][j];
 }
 }
 }
 return result;
 }
 ~matrix() {
 flush();
 }
};
// this function returns a column matrix
matrix* col_mat(int first, int second, int third) {
 matrix* result = new matrix(4, 1);
 result->val[0][0] = first;
 result->val[1][0] = second;
 result->val[2][0] = third;
 result->val[3][0] = 1;
 return result;
}
matrix* diag4(double sx, double sy, double sz) {
 matrix* result = new matrix(4, 4);
 result->val[0][0] = sx;
 result->val[1][1] = sy;
 result->val[2][2] = sz;
 result->val[3][3] = 1;
 return result;
}

matrix* rotate(matrix* original, double degree, char axis) {
 matrix* trig = diag4(1, 1, 1);
 if (axis == 'x') {
 // second column
 trig->val[1][1] = cos(degree);
 trig->val[2][1] = sin(degree);
 // third column
 trig->val[1][2] = -sin(degree);
 trig->val[2][2] = cos(degree);
 }
 else if (axis == 'y') {
 // first column
 trig->val[0][0] = cos(degree);
 trig->val[2][0] = sin(degree);
 // third column
 trig->val[0][2] = -sin(degree);
 trig->val[2][2] = cos(degree);
 }
 else if (axis == 'z') {
 // first column
 trig->val[0][0] = cos(degree);
 trig->val[1][0] = sin(degree);
 // second column
 trig->val[0][1] = -sin(degree);
 trig->val[1][1] = cos(degree);
 }
 // fourth column
 trig->val[3][3] = 1;
 matrix* result = (*trig) * original;
 delete trig;
 delete original;
 return result;
}
double torad(double degree) {
 return degree * 3.141592653f / 180;
}
matrix* reflect(matrix* original, char reflection_type) {
 matrix* change = nullptr;
 if (reflection_type == 'x')
 change = diag4(1, -1, -1);
 else if (reflection_type == 'y')
 change = diag4(-1, 1, -1);
 else if (reflection_type == 'z')
 change = diag4(-1, -1, 1);
 else if (reflection_type == 'o')
 change = diag4(-1, -1, -1);
 else
 return 0;
 matrix* result = *change * original;
 delete change;
 delete original;
 return result;
}
void display(matrix* mat, char* msg = nullptr) {
 if (mat == nullptr) {
 cout << "Matrix is empty!";
 return;
 }
 if (msg != nullptr)
 puts(msg);
 for (int i = 0; i < mat->rows; i++) {
 for (int j = 0; j < mat->cols; j++) {
 cout << "%.1f ", mat->val[i][j];
 }
 cout << "\n";
 }
}


int main() {
 double x, y, z;
 int choice;
 cout << "Enter x: ";
 cin >> x;
 cout << "Enter y: ";
 cin >> y;
 cout << "Enter z: ";
 cin >> z;
 matrix* mat = col_mat(x, y, z);
 cout << "1. Reflection\n";
 cout << "2. Rotation\n";
 char axis;
 double degree;
 restart:
 cout << "Enter your choice: ";
 cin >> choice;
 switch (choice) {
 case 1:
 cout << "Enter axis: ";
 cin >> axis;
 mat = reflect(mat, axis);
 cout << "\nAfter reflection the points are: ";
 break;
 case 2:
 cout << "Enter axis: ";
 cin >> axis;
 cout << "Enter degree: ";
 cin >> degree;
 mat = rotate(mat, degree, axis);
 cout << "\nAfter rotation the points are: ";
 break;
 case 3:
 goto end;
 default:
 cout << "Please enter a valid choice!";
 goto restart;
 }

 x = mat->val[0][0];
 y = mat->val[1][0];
 z = mat->val[2][0];
 cout << '\n' << '(' << x << ", " << y << ", " << z << ')';
end:
 return 0;
}
