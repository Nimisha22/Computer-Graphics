

//Anish Vaidya  Assignment -10

#include <iostream>
#include <graphics.h>
#include <math.h>


using namespace std;


void koch();
void Bezier();
void koch_caller();

int main()
{
    int ch;

    cout<<"\n********Assignment 10********";
    cout<<"\n\n1. Draw Beizer Curve";
    cout<<"\n2. Draw Koch Curve using fractals";
    cout<<"\n3. Exit";
    cout<<"\nEnter your choice: ";
    cin>>ch;


    while(1)
    {
       switch(ch)
       {

            case 1:
                Bezier();
                break;

            case 2:
                koch_caller();
                break;

            case 3:
                exit(0);

       }
    }


}// main ends here




void koch(int x1, int y1, int x2, int y2, int it)
{

    float angle = 60 *(M_PI/180);
    int x3 = (2*x1 + x2)/3;
    int y3 = (2*y1 + y2)/3;

    int x4 = (x1 + 2*x2)/3;
    int y4 = (y1 + 2*y2)/3;

    int x = x3 + (x4 - x3)* cos(angle) + (y4-y3) * sin(angle);
    int y = y3 - (x4 - x3)* sin(angle) + (y4-y3) * cos(angle);



    if(it > 0)
    {

        koch(x1, y1, x3, y3, it-1);
        koch(x3, y3, x, y, it-1);
        koch(x, y, x2, y2, it-1);
        koch(x4, y4, x2, y2, it-1);
    }


    else
    {

        line(x1, y1, x3, y3);
        line(x3, y3, x, y);
        line(x, y, x4, y4);
        line(x4, y4, x2, y2);
    }


}//koch ends here





void koch_caller()
{

    int gd = DETECT, gm;

    initgraph(&gd, &gm, "C:\\TURBOC3\\BGI");

    int v1x = 100, v1y = 100, v2x = 200, v2y = 100, v3x = 150, v3y = 200;


    line(v1x, v1y, v2x, v2y);
    line(v2x, v2y, v3x, v3y);
    line(v3x, v3y, v1x, v1y);
    delay(3000);
    cleardevice();


    delay(1000);

    koch(v1x, v1y, v2x, v2y, 4);
    koch(v2x, v2y, v3x, v3y, 4);
    koch(v3x, v3y, v1x, v1y, 4);

    delay(10000);
}//koch_caller ends here






void Bezier()
{

    int x[4],y[4],i;
    double put_x,put_y,t;
    int gd=DETECT,gm;


    cout<<"\n****** Bezier Curve ***********";
    cout<<"\n Please enter x and y coordinates:  ";

    initgraph(&gd,&gm,"C:\\TURBOC3\\BGI");

    for(i=0;i<4;i++)
    {
        cin>>x[i] >>y[i];
        putpixel(x[i],y[i],3);                // Control Points
    }

    for(t=0.0;t<=1.0;t=t+0.001)             // t always lies between 0 and 1
    {
        put_x = pow(1-t,3)*x[0] + 3*t*pow(1-t,2)*x[1] + 3*t*t*(1-t)*x[2] + pow(t,3)*x[3]; // Formula to draw curve
        put_y =  pow(1-t,3)*y[0] + 3*t*pow(1-t,2)*y[1] + 3*t*t*(1-t)*y[2] + pow(t,3)*y[3];
        putpixel(put_x,put_y, WHITE);            // putting pixel
    }

    getch();
    closegraph();
}

