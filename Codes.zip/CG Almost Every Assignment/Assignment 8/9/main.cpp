
#include <conio.h>
#include <graphics.h>
#include <math.h>
#include <stdio.h>

using namespace std;

int draw_background(){
        line(100,300,100,400);
        line(100,400,200,400);
        line(100,300,200,400);
        line(400,400,500,400);
        line(400,400,500,300);
        line(500,300,500,400);
        line(200,400,400,400);
        return 0;
}

int move_right_to_left_down(){
    for(int i =0;i<70;i++){
        draw_background();
        circle(150+i,300+i,35);
        delay(10);
        cleardevice();
    }
    return 0;
}

int move_right_to_left_straight(){
    for(int i=0;i<160;i++){     //155
        draw_background();
        circle(221+i,370-3,35);   //y=370
        delay(10);
        cleardevice();
    }
    return 0;
}

int move_right_to_left_up(){
    for(int i=0;i<70;i++){
        draw_background();
        circle(381+i,370-i,35);
        delay(10);
        cleardevice();
    }
    return 0;
}

int move_left_to_right_down(){
    for(int i=0;i<70;i++){
        draw_background();
        circle(451-i,300+i,35);
        delay(10);
        cleardevice();
    }
    return 0;
}



int move_left_to_right_straight(){
    for(int i=0;i<160;i++){     //155
        draw_background();
        circle(381-i,370-3,35);   //y=370
        delay(10);
        cleardevice();
    }
    return 0;
}

int move_left_to_right_up(){
    for(int i=0;i<70;i++){
        draw_background();
        circle(221-i,370-i,35);
        delay(10);
        cleardevice();
    }
    return 0;
}


int main() {
    int gd = DETECT, gm;
    initgraph(&gd, &gm, (char*) "C:\\TURBOC3\\BGI");
    while(1){
        move_right_to_left_down();
        move_right_to_left_straight();
        move_right_to_left_up();
        move_left_to_right_down();
        move_left_to_right_straight();
        move_left_to_right_up();
    }
    getch();
    closegraph();
    return 0;

}
